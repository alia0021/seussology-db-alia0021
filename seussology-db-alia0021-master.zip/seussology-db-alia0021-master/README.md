# Seussology DB

## Objective
For this assignment you will be demonstrating your skills and understanding of SQL Queries by creating queries that create, read, update, and delete data from the Seussology Database.

## Database
For this assignment you will be using the Seussology Database which is provided with repository as the [Seussology SQL File](seussology.sql).

## Requirements
The following requirement must be met in order to complete the assignment successfully: 

### 1. Clone the Repository
Clone this repository from GitHub and use the provided file to complete the assignment.

### 2. Import the Seussology Database
To import the database, we will be using [Adminer](https://www.adminer.org/). Adminer is a GUI database manager for MySQL databases. It is also installed by default with Local by Flywheel.

#### Open Adminer
1. Open Local by FlyWheel
2. Start the MTM6331 site
3. Click the "Database" tab
4. Click the "Adminer" button

#### Import Database
1. From the Adminer homepage, click on the "Import" link found in left side of the page.
2. Choose the `seussology.sql` file found in this repository and clicked the "Execute" button

### Select Database
1. Use the select box in the top left corner to select `seussology`
2. You should now see three tables, books, categories, and quotes. You will be able to complete the in-class exercise from this database. 
3. Clicking the "select" next to each table name will display the table data
4. Click the "SQL command" link will allow you to execute custom SQL commands

### 3. Create SQL Queries
Create **ONE** query for each of the 10 tasks below. The queries should be saved in the `queries.sql` file.

#### 1. Retrieve all columns and rows from the `categories` table

![Results of Query 1](images/results-1.png)

#### 2. Retrieve the book title (`book_title`) with the book id (`book_id`) of 13 from the `books` table

![Results of Query 2](images/results-2.png)

#### 3. Retrieve all the book titles (`book_title`) from the `books` table with a number of pages (`book_pages`) greater than 35 and less than 56.

![Results of Query 3](images/results-3.png)

#### 4. Retrieve all the quotes (`quote`) from the `quotes` table that start with the word “Think”.

![Results of Query 4](images/results-4.png)

#### 5. Retrieve the category id (`category_id`) and number of books in each category from the `books` table, and sort the results by the number of books with the highest number first.

![Results of Query 5](images/results-5.png)

#### 6. Using an INNER JOIN, retrieve the first 5 book titles (`book_title`) and category name (`category_name`) when the results are sorted by the book title sort (`book_title_sort`) column.

![Results of Query 6](images/results-6.png)

#### 7. Using INNER JOINs, retrieve the second set of 5 book titles (`book_title`) and quotes (`quotes`) for all of the books in the “Beginner’s Books” category when the results are sorted by the book title (`book_title`).

![Results of Query 7](images/results-7.png)

#### 8. Insert a new quote into the `quotes` table with the following data:

| Columns | Values                                          |
|---------|-------------------------------------------------|
| quote   | "The fools that I saw were none other than you" |
| book_id | 9                                               |

#### 9. Using subqueries, update all of the quotes in the `quotes` table for the book “The Big Brag” to the book id for the book “Yertle the Turtle”

> *Do **NOT** use the book ids directly. You need to retrieve the id using the book titles. This should be done in **ONE** query.*

> *You **MUST** complete task 8 first!* 

#### 10. Remove the book "The Big Brag" from the `books` table. 

> *You **MUST** complete task 9 first!* 