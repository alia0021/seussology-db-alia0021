-- 1. Retrieve all columns and rows from the `categories` table

SELECT * FROM categories
-- 2. Retrieve the book title (`book_title`) with the book id (`book_id`) of 13 from the `books` table
SELECT book_title
FROM books
WHERE book_id = 13

-- 3. Retrieve all the book titles (`book_title`) from the `books` table with a number of pages (`book_pages`) greater than 35 and less than 56.
SELECT book_title
FROM books
WHERE book_pages
BETWEEN 36 AND 55


-- 4. Retrieve all the quotes (`quote`) from the `quotes` table that start with the word “Think”.
SELECT quote
FROM quotes
WHERE quote
LIKE "think%"


-- 5. Retrieve the category id (`category_id`) and number of books in each category from the `books` table, and sort the results by the number of books with the highest number first.
SELECT category_id, COUNT(*) AS 'Number of Books'
FROM books 
GROUP BY category_id
ORDER BY COUNT(*) DESC

-- 6. Using an INNER JOIN, retrieve the first 5 book titles (`book_title`) and category name (`category_name`) when the results are sorted by the book title sort (`book_title_sort`) column.

SELECT books.book_title,categories.category_name
FROM books
INNER JOIN categories
ON books.category_id = categories.category_id
ORDER BY book_title_sort
LIMIT 5
-- 7. Using INNER JOINs, retrieve the second set of 5 quotes (`quotes`) and book titles (`book_title`) for all of the books in the “Beginner’s Books” category when the results are sorted by the book title (`book_title`)
SELECT books.book_title, quotes.quote, categories.category_name
FROM books
RIGHT JOIN categories
ON books.category_id = categories.category_id
INNER JOIN quotes
ON books.book_id = quotes.book_id
WHERE categories.category_name = 'Beginner Books'
ORDER BY book_title
LIMIT 5,5

-- 8. Insert a new quote into the `quotes` table with the following data: quote = "The fools that I saw were none other than you", book_id = 9

INSERT quotes (quote, book_id)
VALUES ('The fools that I saw were none other than you', 9)
-- Once I inserted the new quote, I then used the below to confirm if it was added properly into the table
SELECT quote
from quotes
where book_id = 9
-- 9. Using subqueries, update all of the quotes in the `quotes` table for the book “The Big Brag” to the book id for the book “Yertle the Turtle”

UPDATE quotes
SET book_id = 
(SELECT book_id 
FROM books 
WHERE book_title = 'Yertle the Turtle')
WHERE book_id = 
(SELECT book_id 
FROM books 
WHERE book_title = 'The Big Brag')
--- Confirmed if it was done correctly
SELECT quote_id, quote, book_id
FROM quotes
WHERE quote_id = 11
-- 10. Remove the book "The Big Brag" from the `books` table. 
DELETE
FROM books
WHERE book_title = 'The Big Brag'
Limit 1
--- to check if it was deleted and I got a return of "no rows."
SELECT book_title
FROM books
WHERE book_id = 9;





